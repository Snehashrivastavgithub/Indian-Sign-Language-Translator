const videoElement = document.getElementById('webcam');
const canvasElement = document.getElementById('canvas');
const canvasCtx = canvasElement.getContext('2d');

let camera;

// MediaPipe Hands
const hands = new Hands({
  locateFile: (file) => {
    return `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`;
  }
});

hands.setOptions({
  maxNumHands: 1,
  modelComplexity: 1,
  minDetectionConfidence: 0.7,
  minTrackingConfidence: 0.7
});

// When hand detected
hands.onResults(results => {
  canvasCtx.save();
  canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);
  canvasCtx.drawImage(results.image, 0, 0, canvasElement.width, canvasElement.height);

  if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
    
    const landmarks = results.multiHandLandmarks[0];

    // draw hand
    drawConnectors(canvasCtx, landmarks, HAND_CONNECTIONS, {color: '#a855f7'});
    drawLandmarks(canvasCtx, landmarks, {color: '#fff'});

    // send landmarks to prediction model
    const predicted = dummyPredict(landmarks);
    document.getElementById("output").innerText = predicted;
  }

  canvasCtx.restore();
});

// Start camera
function startCamera() {
  camera = new Camera(videoElement, {
    onFrame: async () => {
      await hands.send({ image: videoElement });
    },
    width: 640,
    height: 480
  });
  camera.start();
}

// Placeholder prediction
function dummyPredict(landmarks) {
  return "Detecting gesture...";
}
const video = document.getElementById("video");
if (!video) {
    alert("Video element not found!");
    return;
}
